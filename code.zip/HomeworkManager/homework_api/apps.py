from django.apps import AppConfig


class HomeworkApiConfig(AppConfig):
    name = 'homework_api'
